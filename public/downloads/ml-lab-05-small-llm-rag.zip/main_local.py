import shutil
import subprocess
import sys
import time
from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import requests

OLLAMA_BASE = "http://localhost:11434"
MODEL = "phi3:mini"  # alternativa: "tinyllama", "gemma:2b", "qwen2:0.5b"


def split_chunks(text: str):
    return [l.strip() for l in text.splitlines() if l.strip()]


def retrieve_context(query: str, chunks: list[str], top_k: int = 2):
    vectorizer = TfidfVectorizer()
    X = vectorizer.fit_transform(chunks + [query])
    query_vec = X[-1]
    docs_vec = X[:-1]
    sims = cosine_similarity(query_vec, docs_vec).flatten()
    top_idx = sims.argsort()[-top_k:][::-1]
    return [chunks[i] for i in top_idx], sims[top_idx]


def ollama_installed() -> bool:
    return shutil.which("ollama") is not None


def ollama_running() -> bool:
    try:
        requests.get(f"{OLLAMA_BASE}/api/tags", timeout=3)
        return True
    except requests.exceptions.RequestException:
        return False


def start_ollama_server():
    print("Avvio Ollama server in background...")
    subprocess.Popen(
        ["ollama", "serve"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    for _ in range(15):
        time.sleep(1)
        if ollama_running():
            print("Ollama server avviato.")
            return
    print("ERRORE: Ollama server non risponde dopo 15 secondi.")
    sys.exit(1)


def model_downloaded() -> bool:
    try:
        resp = requests.get(f"{OLLAMA_BASE}/api/tags", timeout=5)
        models = [m["name"] for m in resp.json().get("models", [])]
        return any(m.startswith(MODEL.split(":")[0]) for m in models)
    except Exception:
        return False


def pull_model():
    print(f"Scarico il modello '{MODEL}' (solo la prima volta)...")
    result = subprocess.run(["ollama", "pull", MODEL])
    if result.returncode != 0:
        print(f"ERRORE: impossibile scaricare '{MODEL}'.")
        sys.exit(1)
    print("Modello pronto.")


def ensure_ollama():
    if not ollama_installed():
        print("Ollama non è installato.")
        print("Scaricalo da: https://ollama.com")
        print("Dopo l'installazione rilancia questo script.")
        sys.exit(1)

    if not ollama_running():
        start_ollama_server()

    if not model_downloaded():
        pull_model()


def ask_ollama(prompt: str) -> str:
    response = requests.post(
        f"{OLLAMA_BASE}/api/generate",
        json={"model": MODEL, "prompt": prompt, "stream": False, "options": {"num_predict": 150}},
        timeout=120,
    )
    response.raise_for_status()
    return response.json()["response"].strip()


def main():
    print("=" * 70)
    print(f"CH9 — Small LLM + Mini RAG  [Livello 2 — Locale: {MODEL}]")
    print("=" * 70 + "\n")

    ensure_ollama()

    kb_path = Path("docs/knowledge_base.txt")
    chunks = split_chunks(kb_path.read_text(encoding="utf-8"))

    query_utente = "Quando conviene usare RAG invece del fine-tuning?"
    retrieved, scores = retrieve_context(query_utente, chunks, top_k=2)
    context = "\n".join([f"- {c}" for c in retrieved])

    print(f"\nQuery: {query_utente}")
    print("\nChunk recuperati dalla knowledge base:")
    for i, (c, s) in enumerate(zip(retrieved, scores), start=1):
        print(f"  {i}. (score={s:.3f}) {c}")

    prompt_no_rag = (
        f"Rispondi in italiano in 2-3 frasi.\n"
        f"Domanda: {query_utente}\nRisposta:"
    )
    prompt_rag = (
        f"Usa SOLO il contesto seguente per rispondere in italiano in 2-3 frasi.\n"
        f"Contesto:\n{context}\n\n"
        f"Domanda: {query_utente}\nRisposta:"
    )

    print("\n--- Output senza contesto (zero-shot) ---")
    print(ask_ollama(prompt_no_rag))

    print("\n--- Output con contesto (mini RAG) ---")
    print(ask_ollama(prompt_rag))

    print("\nNota didattica:")
    print("- Il modello gira interamente in locale, nessun dato esce dalla macchina")
    print("- La differenza tra le due risposte mostra l'effetto del contesto iniettato dal RAG")


if __name__ == "__main__":
    main()
