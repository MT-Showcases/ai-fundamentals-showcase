"""
Livello 3 — Fine-tuning con LoRA su gpt2-small-italian.

Requisiti hardware minimi:
  - Apple Silicon (M1/M2/M3) oppure GPU NVIDIA con 4GB+ VRAM
  - Su CPU pura: gira (~1 minuto)

Cosa dimostra:
  - Il fine-tuning "cuoce" la conoscenza dentro i pesi del modello
  - Dopo il training, il modello completa frasi di dominio senza bisogno di contesto
  - Limite onesto: fa solo completamento di testo, non segue istruzioni
  - Conclusione: per Q&A serve comunque RAG + modello capace (livelli 1 e 2)

INPUT:
  - docs/finetune_data.txt  : 12 frasi di dominio usate come dati di training
  - 3 prompt di test        : frasi parziali per vedere il completamento prima/dopo

OUTPUT:
  - Completamento delle 3 frasi PRIMA del fine-tuning (baseline)
  - Loss di training ogni 10 step (la loss scende = il modello sta imparando)
  - Completamento delle stesse 3 frasi DOPO il fine-tuning (confronto)
"""

import sys
from pathlib import Path
import torch
from transformers import GPT2LMHeadModel, GPT2Tokenizer, TrainingArguments, Trainer
from peft import LoraConfig, get_peft_model, TaskType
from torch.utils.data import Dataset

sys.stdout.reconfigure(encoding="utf-8")

HF_MODEL_ID  = "GroNLP/gpt2-small-italian"
LOCAL_MODEL  = "./models/gpt2-small-italian"
LORA_R       = 8
LORA_ALPHA   = 16
MAX_LENGTH   = 64
EPOCHS       = 30
BATCH_SIZE   = 4


def ensure_model():
    model_path = Path(LOCAL_MODEL)
    if not model_path.exists():
        print(f"Modello non trovato in locale. Scarico '{HF_MODEL_ID}' (~500MB)...")
        tokenizer = GPT2Tokenizer.from_pretrained(HF_MODEL_ID)
        model = GPT2LMHeadModel.from_pretrained(HF_MODEL_ID)
        model_path.mkdir(parents=True, exist_ok=True)
        tokenizer.save_pretrained(LOCAL_MODEL)
        model.save_pretrained(LOCAL_MODEL)
        print("Modello salvato in locale. Non verra' riscaricato nelle prossime esecuzioni.\n")
    else:
        print(f"Modello trovato in locale: {LOCAL_MODEL}\n")


class TextDataset(Dataset):
    def __init__(self, texts: list[str], tokenizer: GPT2Tokenizer):
        self.encodings = tokenizer(
            texts,
            truncation=True,
            padding="max_length",
            max_length=MAX_LENGTH,
            return_tensors="pt",
        )

    def __getitem__(self, idx):
        item = {k: v[idx] for k, v in self.encodings.items()}
        item["labels"] = item["input_ids"].clone()
        return item

    def __len__(self):
        return len(self.encodings["input_ids"])


def generate(model, tokenizer, prompt: str, max_new_tokens: int = 40) -> str:
    inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
    with torch.no_grad():
        output = model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            do_sample=False,
            pad_token_id=tokenizer.eos_token_id,
        )
    return tokenizer.decode(output[0], skip_special_tokens=True)


def main():
    print("=" * 70)
    print("CH9 — Fine-tuning con LoRA  [Livello 3]")
    print("=" * 70 + "\n")

    ensure_model()

    # INPUT 1: frasi di dominio usate per il training
    data_path = Path("docs/finetune_data.txt")
    texts = [l.strip() for l in data_path.read_text(encoding="utf-8").splitlines() if l.strip()]
    print(f"Dati di training ({len(texts)} frasi da {data_path}):")
    for t in texts:
        print(f"  - {t}")

    print("\nCarico tokenizer e modello base...")
    tokenizer = GPT2Tokenizer.from_pretrained(LOCAL_MODEL)
    tokenizer.pad_token = tokenizer.eos_token
    dataset = TextDataset(texts, tokenizer)
    base_model = GPT2LMHeadModel.from_pretrained(LOCAL_MODEL)

    # INPUT 2: prompt di test — frasi parziali per misurare il prima/dopo
    test_prompts = [
        "RAG è ideale quando",
        "Il fine-tuning modifica",
        "Zero-shot è rapido ma",
    ]

    print("\n--- Completamenti PRIMA del fine-tuning (baseline) ---")
    print("Il modello non conosce ancora il dominio:\n")
    for p in test_prompts:
        out = generate(base_model, tokenizer, p)
        print(f"  Input:  '{p}'")
        print(f"  Output: '{out[len(p):].strip()}'\n")

    # LoRA: si allena solo lo 0.27% dei parametri — veloce e leggero
    lora_config = LoraConfig(
        task_type=TaskType.CAUSAL_LM,
        r=LORA_R,
        lora_alpha=LORA_ALPHA,
        lora_dropout=0.05,
        target_modules=["c_attn"],
    )
    model = get_peft_model(base_model, lora_config)
    trainable, total = model.get_nb_trainable_parameters()
    print(f"Parametri trainabili con LoRA: {trainable:,} / {total:,} ({100*trainable/total:.2f}%)")
    print("LoRA modifica solo una piccola parte del modello: veloce e leggero.\n")

    print("Avvio fine-tuning...")
    args = TrainingArguments(
        output_dir="./lora_output",
        num_train_epochs=EPOCHS,
        per_device_train_batch_size=BATCH_SIZE,
        learning_rate=3e-4,
        logging_steps=10,
        save_strategy="no",
        report_to="none",
    )
    trainer = Trainer(model=model, args=args, train_dataset=dataset)
    trainer.train()
    print("Fine-tuning completato.\n")

    model.eval()
    print("--- Completamenti DOPO il fine-tuning ---")
    print("Stesso modello, stessi prompt — ma ora conosce il dominio:\n")
    for p in test_prompts:
        out = generate(model, tokenizer, p)
        print(f"  Input:  '{p}'")
        print(f"  Output: '{out[len(p):].strip()}'\n")

    print("=" * 70)
    print("Nota didattica:")
    print("  - La loss scende = il modello ha assorbito le frasi di dominio")
    print("  - Il completamento dopo e' piu' pertinente al testo di training")
    print("  - Ma senza istruzioni esplicite non sa rispondere a domande")
    print("  - Per Q&A serve RAG + modello capace (Livelli 1 o 2)")
    print("=" * 70)


if __name__ == "__main__":
    main()
