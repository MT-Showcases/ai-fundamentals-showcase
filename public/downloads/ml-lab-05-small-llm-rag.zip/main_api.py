import os
from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from dotenv import load_dotenv

load_dotenv()

GROQ_MODEL = "llama-3.1-8b-instant"
ANTHROPIC_MODEL = "claude-haiku-4-5-20251001"


def split_chunks(text: str):
    return [l.strip() for l in text.splitlines() if l.strip()]


def retrieve_context(query: str, chunks: list[str], top_k: int = 2):
    vectorizer = TfidfVectorizer()
    X = vectorizer.fit_transform(chunks + [query])
    query_vec = X[-1]
    docs_vec = X[:-1]
    sims = cosine_similarity(query_vec, docs_vec).flatten()
    top_idx = sims.argsort()[-top_k:][::-1]
    return [chunks[i] for i in top_idx], sims[top_idx]


def build_client():
    groq_key = os.environ.get("GROQ_API_KEY", "")
    anthropic_key = os.environ.get("ANTHROPIC_API_KEY", "")

    if groq_key and not groq_key.startswith("gsk_..."):
        from openai import OpenAI
        print(f"Provider: Groq  |  Modello: {GROQ_MODEL}")
        return "groq", OpenAI(api_key=groq_key, base_url="https://api.groq.com/openai/v1")

    if anthropic_key and not anthropic_key.startswith("sk-ant-..."):
        import anthropic
        print(f"Provider: Anthropic  |  Modello: {ANTHROPIC_MODEL}")
        return "anthropic", anthropic.Anthropic(api_key=anthropic_key)

    print("Nessuna chiave trovata nel file .env")
    print("Copia .env.example in .env e inserisci la tua chiave API.")
    raise SystemExit(1)


def ask(provider: str, client, prompt: str) -> str:
    if provider == "groq":
        response = client.chat.completions.create(
            model=GROQ_MODEL,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=200,
        )
        return response.choices[0].message.content.strip()

    response = client.messages.create(
        model=ANTHROPIC_MODEL,
        max_tokens=200,
        messages=[{"role": "user", "content": prompt}],
    )
    return response.content[0].text.strip()


def main():
    print("=" * 70)
    print("CH9 — Small LLM + Mini RAG  [Livello 1 — API]")
    print("=" * 70 + "\n")

    provider, client = build_client()

    kb_path = Path("docs/knowledge_base.txt")
    chunks = split_chunks(kb_path.read_text(encoding="utf-8"))

    query_utente = "Quando conviene usare RAG invece del fine-tuning?"
    retrieved, scores = retrieve_context(query_utente, chunks, top_k=2)
    context = "\n".join([f"- {c}" for c in retrieved])

    print(f"\nQuery: {query_utente}")
    print("\nChunk recuperati dalla knowledge base:")
    for i, (c, s) in enumerate(zip(retrieved, scores), start=1):
        print(f"  {i}. (score={s:.3f}) {c}")

    prompt_no_rag = (
        f"Rispondi in italiano in 2-3 frasi.\n"
        f"Domanda: {query_utente}"
    )
    prompt_rag = (
        f"Usa SOLO il contesto seguente per rispondere in italiano in 2-3 frasi.\n"
        f"Contesto:\n{context}\n\n"
        f"Domanda: {query_utente}"
    )

    print("\n--- Output senza contesto (zero-shot) ---")
    print(ask(provider, client, prompt_no_rag))

    print("\n--- Output con contesto (mini RAG) ---")
    print(ask(provider, client, prompt_rag))

    print("\nNota didattica:")
    print("- La risposta RAG è ancorata ai tuoi documenti, non alla conoscenza generica del modello")
    print("- Cambia la knowledge base: il modello si adatta senza nessun ri-addestramento")


if __name__ == "__main__":
    main()
