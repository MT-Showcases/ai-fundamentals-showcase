# ML Lab 5 — Small LLM + Mini RAG
### Capitolo 9 — Fine-tuning e Transfer Learning

Questo lab dimostra in modo pratico la differenza tra **zero-shot**, **RAG** e **fine-tuning** applicati a un caso concreto: rispondere a domande su una knowledge base aziendale.

Tre livelli di difficoltà — scegli quello adatto al tuo hardware.

---

## Come funziona (flusso dati)

**Livelli 1 e 2 — RAG:**
```
Query utente
    │
    ▼
Retrieval TF-IDF       ← cerca i chunk più rilevanti in knowledge_base.txt
    │
    ├── Prompt zero-shot:  solo la query
    └── Prompt RAG:        query + chunk recuperati
          │
          ▼
        Modello LLM    ← genera due risposte da confrontare
```

**Livello 3 — Fine-tuning:**
```
finetune_data.txt (12 frasi di dominio)
    │
    ▼
Training LoRA          ← modifica solo lo 0.27% dei pesi del modello
    │
    ▼
Test con frasi parziali  ← stessi prompt prima e dopo il training
    │
    ▼
Confronto output       ← il modello ora conosce il dominio senza contesto
```

---

## Livello 1 — API (qualsiasi computer)

Usa **Groq** (gratuita) o **Anthropic Claude** come modello.  
Il confronto zero-shot vs RAG si vede in modo netto e immediato.

```bash
# Copia .env.example in .env e inserisci la tua chiave API
cp .env.example .env

pip install -r requirements_api.txt
python main_api.py
```

La chiave Groq è gratuita su https://console.groq.com.  
Se sono presenti entrambe le chiavi, viene usata Groq.

---

## Livello 2 — Locale con Ollama (hardware medio)

Tutto gira in locale. Nessun dato esce dalla macchina.  
Richiede almeno 8GB di RAM. Lo script gestisce download e avvio in automatico.

```bash
# Installa Ollama da https://ollama.com, poi:
pip install -r requirements_local.txt
python main_local.py
```

Lo script verifica se Ollama è attivo, lo avvia se necessario, e scarica `phi3:mini` se non è già presente.  
Per usare un modello diverso, modifica la variabile `MODEL` in cima a `main_local.py`.

---

## Livello 3 — Fine-tuning con LoRA (GPU o Apple Silicon)

Esegue un vero fine-tuning su `gpt2-small-italian` usando LoRA.  
Il modello (~500MB) viene scaricato e salvato in `models/` alla prima esecuzione.

**Hardware minimo:** Apple Silicon M1+ oppure GPU NVIDIA con 4GB+ VRAM.  
Su CPU pura gira in circa 1 minuto.

```bash
pip install -r requirements_finetune.txt
python main_finetune.py
```

**Cosa osservare:**
- Prima del training: il modello completa le frasi in modo generico, non conosce il dominio
- Durante il training: la loss scende — il modello sta assorbendo le frasi di dominio
- Dopo il training: gli stessi prompt producono completamenti pertinenti

**Limite onesto:** `gpt2-small-italian` fa solo completamento di testo, non segue istruzioni.  
Per Q&A strutturate serve un modello capace + RAG (Livelli 1 o 2).

---

## File di dati

**`docs/knowledge_base.txt`** — 5 frasi usate come base documentale dal RAG (Livelli 1 e 2).  
**`docs/finetune_data.txt`** — 12 frasi di dominio usate per il training (Livello 3).  
Aggiungere frasi a questi file è il modo più semplice per personalizzare il lab.

---

## Confronto tra approcci

| | Zero-shot | RAG | Fine-tuning |
|---|---|---|---|
| Conosce i tuoi documenti? | No | Sì, al volo | Sì, dopo il training |
| Si aggiorna senza retraining? | — | Sì | No |
| Hardware richiesto | Qualsiasi | Qualsiasi | GPU / Apple Silicon |
| Quando usarlo | Prototipazione rapida | Dati che cambiano spesso | Comportamento molto specifico |

**Regola pratica del capitolo 9:**  
Parti sempre da RAG + prompt robusti. Passa al fine-tuning solo se hai un gap persistente e dati di qualità sufficienti.
