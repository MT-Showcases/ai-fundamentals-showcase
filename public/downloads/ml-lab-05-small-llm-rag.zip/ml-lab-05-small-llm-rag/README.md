# ML Lab 5 — Small LLM + Mini RAG (CH9 Extra)

Questo lab mostra **quando ha senso usare un mini-LLM locale con RAG** invece di fare fine-tuning.

## Cosa fa
1. Carica una mini knowledge base locale (`docs/knowledge_base.txt`)
2. Recupera i chunk più rilevanti con TF-IDF
3. Costruisce un prompt contestualizzato (RAG)
4. Genera risposta con un **modello piccolo** (`sshleifer/tiny-gpt2`)
5. Confronta output senza contesto vs con contesto

## Requisiti
- Python 3.9+
- Prima esecuzione richiede internet per scaricare il modello HuggingFace

## Avvio
```bash
pip install -r requirements.txt
python main.py
```

## Esperimento
Cambia `query_utente` in fondo al file e osserva:
- qualità della risposta
- pertinenza al contesto recuperato
- limiti del mini modello
