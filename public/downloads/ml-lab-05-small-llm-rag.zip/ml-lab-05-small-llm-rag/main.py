import re
from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from transformers import pipeline


def split_chunks(text: str):
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    return lines


def retrieve_context(query: str, chunks: list[str], top_k: int = 2):
    vectorizer = TfidfVectorizer()
    X = vectorizer.fit_transform(chunks + [query])
    query_vec = X[-1]
    docs_vec = X[:-1]
    sims = cosine_similarity(query_vec, docs_vec).flatten()
    top_idx = sims.argsort()[-top_k:][::-1]
    return [chunks[i] for i in top_idx], sims[top_idx]


def clean(text: str):
    text = re.sub(r"\s+", " ", text).strip()
    return text


def main():
    print("=" * 70)
    print("CH9 EXTRA — Small LLM + Mini RAG")
    print("=" * 70)

    kb_path = Path("docs/knowledge_base.txt")
    kb_text = kb_path.read_text(encoding="utf-8")
    chunks = split_chunks(kb_text)

    query_utente = "Quando conviene usare RAG invece del fine-tuning?"

    retrieved, scores = retrieve_context(query_utente, chunks, top_k=2)
    context = "\n".join([f"- {c}" for c in retrieved])

    print("\nQuery:", query_utente)
    print("\nChunk recuperati:")
    for i, (c, s) in enumerate(zip(retrieved, scores), start=1):
        print(f"{i}. (score={s:.3f}) {c}")

    generator = pipeline("text-generation", model="sshleifer/tiny-gpt2")

    prompt_no_rag = f"Domanda: {query_utente}\nRisposta breve e chiara in italiano:"
    prompt_rag = (
        "Usa SOLO il contesto seguente per rispondere in italiano.\n"
        f"Contesto:\n{context}\n\n"
        f"Domanda: {query_utente}\n"
        "Risposta:"
    )

    out_no_rag = generator(prompt_no_rag, max_new_tokens=70, do_sample=False)[0]["generated_text"]
    out_rag = generator(prompt_rag, max_new_tokens=90, do_sample=False)[0]["generated_text"]

    print("\n--- Output senza contesto (zero-shot) ---")
    print(clean(out_no_rag))

    print("\n--- Output con contesto (mini RAG) ---")
    print(clean(out_rag))

    print("\nNota didattica:")
    print("- Modello tiny-gpt2 è volutamente piccolo e limitato")
    print("- L'obiettivo è vedere il workflow RAG, non la qualità assoluta del modello")


if __name__ == "__main__":
    main()
